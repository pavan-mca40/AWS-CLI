import boto3
import json

regions = ["ap-south-1"]
regiontable = "ap-south-1"
dynamodb = boto3.resource('dynamodb',regiontable)
table = dynamodb.Table('crossaccount')
response = table.scan()

def send_to_queue(sqsQueueUrl, messageBody):
    """
    Sends message to the SQS Queue

    Args:
        sqsQueueUrl (str): SQS queue url
        messageBody (str): Message body
    """
    sqsConnection = boto3.client('sqs')
    sqsConnection.send_message(QueueUrl=sqsQueueUrl, MessageBody=messageBody)

def lambda_handler(event, context):
    for i in response['Items']:
        client1 = str(i['client'])
        cross_acc_arn = str(i['Iamrole'])
        accountid = str(i['accountid'])
        # print (cross_acc_arn + "  "+client1)
        STSCLIENT = boto3.client('sts')
        STSkey = STSCLIENT.assume_role(RoleArn=cross_acc_arn,RoleSessionName='Demo')
        AWS_ACCESS_KEY_ID = STSkey['Credentials']['AccessKeyId']
        AWS_SECRET_ACCESS_KEY = STSkey['Credentials']['SecretAccessKey']
        AWS_SESSION_TOKEN = STSkey['Credentials']['SessionToken']
        for regionname in regions:
            accountData={}
            ec2=boto3.resource('ec2',region_name=regionname,aws_access_key_id=AWS_ACCESS_KEY_ID,aws_secret_access_key=AWS_SECRET_ACCESS_KEY,aws_session_token=AWS_SESSION_TOKEN)
            ec2Client=boto3.client('ec2',region_name=regionname,aws_access_key_id=AWS_ACCESS_KEY_ID,aws_secret_access_key=AWS_SECRET_ACCESS_KEY,aws_session_token=AWS_SESSION_TOKEN)
            # Filter instance having specified tag and status running
            filter = [{'Name': 'tag:Auto_Stop_Start', 'Values': ['Yes', 'yes', 'YES']}, {'Name': 'instance-state-name','Values': ['running']}]
            instances = ec2.instances.filter(Filters=filter)
            #Get IDs of all running and tagged instances
            instance_ids = [instance.id for instance in instances]
            accountData = {"Account": accountid, "IntanceIds": instance_ids, "region": regionname, "CrossRoleName": cross_acc_arn}
            print(accountData)
            send_to_queue("	https://sqs.ap-south-1.amazonaws.com/111809595072/Stop_Ec2",str(accountData))