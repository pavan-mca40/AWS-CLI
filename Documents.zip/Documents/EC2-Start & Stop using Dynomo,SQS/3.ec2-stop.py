import boto3
import json
 
regions = ["ap-south-1"]
 
 
def lambda_handler(event, context):
    for msg in event['Records']:
        account_data = msg['body'].replace('\'', '\"')
        json_data = json.loads(account_data)
        regionName = json_data['region']
        cross_account_arn = json_data['CrossRoleName']
        sts_client = boto3.client('sts')
        sts_key = sts_client.assume_role(RoleArn=cross_account_arn, RoleSessionName='Demo')
        aws_access_key = sts_key['Credentials']['AccessKeyId']
        aws_secret_key = sts_key['Credentials']['SecretAccessKey']
        aws_session_token_id = sts_key['Credentials']['SessionToken']
        ec2 = boto3.resource('ec2', region_name=regionName, aws_access_key_id=aws_access_key, aws_secret_access_key=aws_secret_key, aws_session_token=aws_session_token_id)
        instance_ids = json_data['IntanceIds']
        print(instance_ids)
        if len(instance_ids) > 0:
            # Stop the instances
            stop_instances = ec2.instances.filter(InstanceIds=instance_ids).stop()
            print (stop_instances)
        else:
            print ("No instances need to be stopped")