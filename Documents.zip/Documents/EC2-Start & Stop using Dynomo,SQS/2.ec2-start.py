import boto3
import json

regions = ["ap-south-1"]


def lambda_handler(event, context):
    for msg in event['Records']:
        accountData = msg['body'].replace('\'', '\"')
        jsonData = json.loads(accountData)
        accountNumber = jsonData['Account']
        regionName = jsonData['region']
        crossaccountarn = jsonData['CrossRoleName']
        STSCLIENT = boto3.client('sts')
        STSkey = STSCLIENT.assume_role(RoleArn=crossaccountarn,RoleSessionName='Demo')
        AWS_ACCESS_KEY_ID = STSkey['Credentials']['AccessKeyId']
        AWS_SECRET_ACCESS_KEY = STSkey['Credentials']['SecretAccessKey']
        AWS_SESSION_TOKEN = STSkey['Credentials']['SessionToken']
        ec2=boto3.resource('ec2',region_name=regionName,aws_access_key_id=AWS_ACCESS_KEY_ID,aws_secret_access_key=AWS_SECRET_ACCESS_KEY,aws_session_token=AWS_SESSION_TOKEN)
        INSTANCE_IDS = jsonData['IntanceIds']
        print(INSTANCE_IDS)
        if len(INSTANCE_IDS) > 0:
            # Start instances
            starting_instances = ec2.instances.filter(InstanceIds=INSTANCE_IDS).start()
            print (starting_instances)
        else:
            print ("No instances need to start")